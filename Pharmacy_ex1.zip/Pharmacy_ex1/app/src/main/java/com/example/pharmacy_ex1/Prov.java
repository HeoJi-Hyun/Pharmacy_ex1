package com.example.pharmacy_ex1;

import static com.example.pharmacy_ex1.R.id.*;

import android.app.Activity;
import android.app.FragmentManager;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.tabs.TabLayout;

public class Prov extends Activity {
    Fragment tabfrag1, tabfrag2, tabfrag3;
    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prov);

        tabfrag1 = new TabFrag1();
        tabfrag2 = new TabFrag2();
        tabfrag3 = new TabFrag3();



//

        TabLayout tabs = (TabLayout) findViewById(R.id.tabs);
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
    private FragmentManager getSupportFragmentManager(){
        return null;
    }
}
