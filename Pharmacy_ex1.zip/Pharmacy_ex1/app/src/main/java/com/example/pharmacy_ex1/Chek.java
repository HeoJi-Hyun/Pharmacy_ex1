package com.example.pharmacy_ex1;

public class Chek {
}
